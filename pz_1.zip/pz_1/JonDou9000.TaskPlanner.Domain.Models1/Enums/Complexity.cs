﻿namespace JonDou9000.TaskPlanner.Domain.Models1.Enums
{
    public enum Complexity
    {
        None,
        Minutes,
        Hours,
        Days,
        Weeks
    }
}