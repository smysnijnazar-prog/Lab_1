﻿namespace JonDou9000.TaskPlanner.Domain.Models1.Enums
{
    public enum Priority
    {
        None = 0,
        Low = 1,
        Medium = 2,
        High = 3,
        Urgent = 4
    }
}