﻿using JonDou9000.TaskPlanner.Domain.Models1.Enums;

namespace JonDou9000.TaskPlanner.Domain.Models1
{
    public class WorkItem
    {
        // 5. Властивості
        public DateTime CreationDate { get; set; }
        public DateTime DueDate { get; set; }
        public Priority Priority { get; set; }
        public Complexity Complexity { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public bool IsCompleted { get; set; }

        // 6. Перевизначення методу ToString()
        public override string ToString()
        {
            // Використання рядкової інтерполяції
            // Дата у форматі dd.MM.yyyy
            // Пріоритет перетворюється на нижній регістр (ToLower())
            return $"{Title}: due {DueDate:dd.MM.yyyy}, {Priority.ToString().ToLower()} priority";
        }
    }
}